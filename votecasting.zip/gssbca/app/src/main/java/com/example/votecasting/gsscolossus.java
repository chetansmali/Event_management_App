package com.example.votecasting;

public class gsscolossus {
    public String a_college_name,b_college_email,c_college_phone,d_team_head,e1_coding_participate_1,e1_coding_phone_1,e2_coding_participate_2,e2_coding_phone_2,f1_design1_participate_1,f1_design1_phone_1,f2_design1_participate_2,f2_design1_phone_2,g1_BM_participate_1,g1_BM_phone_1,h1_gaming_paticipate_1,h1_gaming_phone_1,i1_cultures_participate_1,i1_cultures_phone_1,i2_cultures_participate_2,i2_cultures_phone_2,i3_cultures_participate_3,i3_cultures_phone_3,i4_cultures_participate_4,i4_cultures_phone_4;


    public gsscolossus(String a_college, String b_college_email, String c_college_phone, String d_team_head, String e1_coding_participate_1, String e1_coding_phone_1, String e2_coding_participate_2, String e2_coding_phone_2, String f1_design1_participate_1, String f1_design1_phone_1, String f2_design1_participate_2, String f2_design1_phone_2, String g1_BM_participate_1, String g1_BM_phone_1, String h1_gaming_paticipate_1, String h1_gaming_phone_1, String i1_cultures_participate_1, String i1_cultures_phone_1, String i2_cultures_participate_2, String i2_cultures_phone_2, String i3_cultures_participate_3, String i3_cultures_phone_3, String i4_cultures_participate_4, String i4_cultures_phone_4) {
        this.a_college_name = a_college;
        this.b_college_email = b_college_email;
        this.c_college_phone = c_college_phone;
        this.d_team_head = d_team_head;
        this.e1_coding_participate_1 = e1_coding_participate_1;
        this.e1_coding_phone_1 = e1_coding_phone_1;
        this.e2_coding_participate_2 = e2_coding_participate_2;
        this.e2_coding_phone_2 = e2_coding_phone_2;
        this.f1_design1_participate_1 = f1_design1_participate_1;
        this.f1_design1_phone_1 = f1_design1_phone_1;
        this.f2_design1_participate_2 = f2_design1_participate_2;
        this.f2_design1_phone_2 = f2_design1_phone_2;
        this.g1_BM_participate_1 = g1_BM_participate_1;
        this.g1_BM_phone_1 = g1_BM_phone_1;
        this.h1_gaming_paticipate_1 = h1_gaming_paticipate_1;
        this.h1_gaming_phone_1 = h1_gaming_phone_1;
        this.i1_cultures_participate_1 = i1_cultures_participate_1;
        this.i1_cultures_phone_1 = i1_cultures_phone_1;
        this.i2_cultures_participate_2 = i2_cultures_participate_2;
        this.i2_cultures_phone_2 = i2_cultures_phone_2;
        this.i3_cultures_participate_3 = i3_cultures_participate_3;
        this.i3_cultures_phone_3 = i3_cultures_phone_3;
        this.i4_cultures_participate_4 = i4_cultures_participate_4;
        this.i4_cultures_phone_4 = i4_cultures_phone_4;
    }
}
